package LuxuryService.projet;

import java.io.File;  // Import the File class
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class FileCreation {



       public void createFile(String input){
            System.out.println("loli");

           String fileName;

           fileName = input + ".txt";

           try{
               File file = new File(fileName);
               if (file.createNewFile()) {
                   System.out.println("File created: " + file.getName());
                   writeFile(fileName);
               } else {
                   System.out.println("File already exists.");
               }
           } catch (IOException e) {
               System.out.println("An error occurred.");
               e.printStackTrace();
           }


       }

       public void writeFile(String fileName){

           try {
               FileWriter myWriter = new FileWriter(fileName);
               myWriter.write("Files in Java might be tricky, but it is fun enough!");
               myWriter.close();
               System.out.println("Successfully wrote to the file.");
           } catch (IOException e) {
               System.out.println("An error occurred.");
               e.printStackTrace();
           }
       }

}

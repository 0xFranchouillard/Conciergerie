package LuxuryService.projet;

import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle error

public class Main {
    public static void main(String[] args) {
        new Frame();
    }
}
